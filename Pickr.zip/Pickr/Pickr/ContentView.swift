import SwiftUI

struct ContentView: View {
    @StateObject private var tokenStore = TokenStore()
    @State private var selectedTab: Int = 0
    
    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {
                SportsView()
                    .environmentObject(tokenStore)
                    .tabItem {
                        Image(systemName: "sportscourt")
                        Text("Sports")
                    }
                    .tag(0)
                
                DealsView()
                    .environmentObject(tokenStore)
                    .tabItem {
                        Image(systemName: "giftcard")
                        Text("Deals")
                    }
                    .tag(1)
                
                MyTakesView()
                    .environmentObject(tokenStore)
                    .tabItem {
                        Image(systemName: "list.bullet.rectangle")
                        Text("MyTakes")
                    }
                    .tag(2)
                
                ProfileView()
                    .environmentObject(tokenStore)
                    .tabItem {
                        Image(systemName: "person.crop.circle")
                        Text("Profile")
                    }
                    .tag(3)
            }
            // help iPad keep the tab bar visible & interactive
            .toolbar(.visible, for: .tabBar)
        }
    }
}

#Preview {
    ContentView()
}

