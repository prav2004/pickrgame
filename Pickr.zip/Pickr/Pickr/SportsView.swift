import SwiftUI

struct SportsView: View {
    @EnvironmentObject var tokenStore: TokenStore
    
    struct HotPick: Identifiable {
        let id = UUID()
        let sport: String
        let matchup: String
        
        let mainLine: String       // e.g. "Lakers +4.5"
        let overUnderLine: String  // e.g. "Total 224.5"
        
        let mainOdds: Double
        let overOdds: Double
        let underOdds: Double
    }
    
    @State private var hotPicks: [HotPick] = [
        HotPick(
            sport: "NBA",
            matchup: "Lakers @ Celtics",
            mainLine: "Lakers +4.5",
            overUnderLine: "Total 224.5",
            mainOdds: 1.90,
            overOdds: 1.85,
            underOdds: 1.85
        ),
        HotPick(
            sport: "NFL",
            matchup: "Chiefs @ 49ers",
            mainLine: "Chiefs -2.5",
            overUnderLine: "Total 48.5",
            mainOdds: 1.88,
            overOdds: 1.80,
            underOdds: 1.95
        ),
        HotPick(
            sport: "Soccer",
            matchup: "Arsenal vs Spurs",
            mainLine: "Arsenal -0.5",
            overUnderLine: "Total 3.0",
            mainOdds: 1.92,
            overOdds: 1.82,
            underOdds: 1.90
        )
    ]
    
    // Current parlay slip (max 1 leg per pick)
    @State private var selectedBets: [BetSelection] = []
    
    // Stake text input
    @State private var stakeText: String = "100"
    
    // Parsed stake from text field
    private var enteredStake: Int {
        Int(stakeText) ?? 0
    }
    
    private var combinedOdds: Double {
        selectedBets.reduce(1.0) { $0 * $1.odds }
    }
    
    private var potentialReturn: Int {
        guard enteredStake > 0 else { return 0 }
        return Int(Double(enteredStake) * combinedOdds)
    }
    
    private var canPlaceParlay: Bool {
        selectedBets.count >= 2 &&
        enteredStake > 0 &&
        enteredStake <= tokenStore.tokens
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TopBar()
                
                List {
                    Section(header: Text("Hottest Picks of the Week")) {
                        ForEach(hotPicks) { pick in
                            let current = selectedBets.first { $0.pickId == pick.id }
                            
                            HotPickRow(
                                pick: pick,
                                currentSelection: current,
                                onSelect: toggleSelection
                            )
                        }
                    }
                    
                    if !selectedBets.isEmpty {
                        Section(header: Text("My Parlay Slip")) {
                            ForEach(selectedBets) { sel in
                                VStack(alignment: .leading) {
                                    Text(sel.description)
                                        .font(.subheadline)
                                    Text("Odds \(sel.odds, specifier: "%.2f")x")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            
                            // Stake input
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text("Stake:")
                                    TextField("Amount", text: $stakeText)
                                        .keyboardType(.numberPad)
                                        .multilineTextAlignment(.trailing)
                                        .frame(width: 80)
                                        .textFieldStyle(.roundedBorder)
                                }
                                
                                Text("Balance: \(tokenStore.tokens) tokens")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                
                                if enteredStake > tokenStore.tokens {
                                    Text("Stake cannot be more than your balance.")
                                        .font(.caption2)
                                        .foregroundStyle(.red)
                                } else if enteredStake <= 0 {
                                    Text("Enter a positive stake to place this parlay.")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Legs: \(selectedBets.count)")
                                    .font(.subheadline)
                                Text("Combined Odds: \(combinedOdds, specifier: "%.2f")x")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                Text("Potential Return: \(potentialReturn) tokens")
                                    .font(.subheadline)
                                    .foregroundStyle(.green)
                            }
                            
                            Button {
                                placeParlay()
                            } label: {
                                Text("Place Parlay (\(selectedBets.count) legs)")
                                    .font(.footnote)
                                    .padding(.vertical, 8)
                                    .frame(maxWidth: .infinity)
                                    .background(canPlaceParlay ? Color.blue.opacity(0.8) : Color.gray.opacity(0.4))
                                    .foregroundColor(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                            .disabled(!canPlaceParlay)
                        }
                    }
                }
            }
        }
    }
    
    // Toggle bet in parlay (only one leg per HotPick)
    private func toggleSelection(_ selection: BetSelection) {
        if let index = selectedBets.firstIndex(where: { $0.pickId == selection.pickId }) {
            if selectedBets[index] == selection {
                // Tap the same leg again → remove it
                selectedBets.remove(at: index)
            } else {
                // Different leg from same game → replace
                selectedBets[index] = selection
            }
        } else {
            // New game → add leg to parlay
            selectedBets.append(selection)
        }
    }
    
    private func placeParlay() {
        guard canPlaceParlay else { return }
        
        let stake = enteredStake
        
        tokenStore.tokens -= stake
        
        let bet = ParlayBet(
            placedAt: Date(),
            legs: selectedBets,
            stake: stake,
            combinedOdds: combinedOdds,
            potentialReturn: potentialReturn,
            status: .pending
        )
        
        // Add to top of MyTakes
        tokenStore.myTakes.insert(bet, at: 0)
        
        // Clear slip
        selectedBets.removeAll()
        // Leave stake text as-is so user can reuse that number
    }
}

struct HotPickRow: View {
    let pick: SportsView.HotPick
    let currentSelection: BetSelection?
    let onSelect: (BetSelection) -> Void
    
    private func isSelected(_ desc: String) -> Bool {
        currentSelection?.description == desc
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(pick.sport)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.thinMaterial)
                    .clipShape(Capsule())
                Spacer()
            }
            
            Text(pick.matchup)
                .font(.headline)
            
            Text(pick.mainLine)
                .font(.subheadline)
            Text(pick.overUnderLine)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    betButton(
                        label: pick.mainLine,
                        odds: pick.mainOdds
                    )
                    Spacer()
                }
                
                HStack {
                    betButton(
                        label: "Over – \(pick.overUnderLine)",
                        odds: pick.overOdds
                    )
                    betButton(
                        label: "Under – \(pick.overUnderLine)",
                        odds: pick.underOdds
                    )
                }
            }
            .padding(.top, 4)
        }
        .padding(.vertical, 6)
    }
    
    private func betButton(label: String, odds: Double) -> some View {
        let desc = "\(pick.matchup): \(label)"
        let selected = isSelected(desc)
        
        return Button {
            let sel = BetSelection(
                pickId: pick.id,
                description: desc,
                odds: odds
            )
            onSelect(sel)
        } label: {
            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(.footnote)
                    .lineLimit(1)
                Text("\(odds, specifier: "%.2f")x")
                    .font(.caption2)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(selected ? Color.blue.opacity(0.8) : Color.blue.opacity(0.2))
            .foregroundColor(selected ? .white : .primary)
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }
}

#Preview {
    SportsView()
        .environmentObject(TokenStore())
}

