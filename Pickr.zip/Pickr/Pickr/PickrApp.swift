import SwiftUI

@main
struct PickrApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()   // <- this MUST be ContentView()
        }
    }
}

