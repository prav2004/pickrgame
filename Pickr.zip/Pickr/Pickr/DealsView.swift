import SwiftUI

struct DealsView: View {
    @EnvironmentObject var tokenStore: TokenStore
    
    struct DealItem: Identifiable {
        let id = UUID()
        let title: String
        let subtitle: String
        let reward: Int
        let type: String   // "Affiliate", "Task", "Achievement"
    }
    
    @State private var deals: [DealItem] = [
        DealItem(title: "Sign up with Partner A",
                 subtitle: "Create an account with our affiliate.",
                 reward: 500,
                 type: "Affiliate"),
        DealItem(title: "Place 5 Picks in a Week",
                 subtitle: "Stay active to get this reward.",
                 reward: 200,
                 type: "Achievement"),
        DealItem(title: "Daily Login",
                 subtitle: "Come back every day to earn tokens.",
                 reward: 25,
                 type: "Task")
    ]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TopBar()
                
                List {
                    Section(header: Text("Earn More Tokens")) {
                        ForEach(deals) { deal in
                            DealRow(deal: deal) {
                                claimDeal(deal)
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func claimDeal(_ deal: DealItem) {
        tokenStore.tokens += deal.reward
    }
}

struct DealRow: View {
    let deal: DealsView.DealItem
    let onClaim: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(deal.type)
                    .font(.caption2)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(.thinMaterial)
                    .clipShape(Capsule())
                
                Spacer()
                
                Text("+\(deal.reward) tokens")
                    .font(.caption)
                    .fontWeight(.semibold)
            }
            
            Text(deal.title)
                .font(.headline)
            
            Text(deal.subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            
            Button(action: onClaim) {
                Text("View / Claim")
                    .font(.footnote)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(.blue.opacity(0.2))
                    .clipShape(Capsule())
            }
            .padding(.top, 4)
        }
        .padding(.vertical, 6)
    }
}

#Preview {
    DealsView()
        .environmentObject(TokenStore())
}

