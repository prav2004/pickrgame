import SwiftUI

struct TopBar: View {
    @EnvironmentObject var tokenStore: TokenStore
    
    var body: some View {
        HStack {
            // App name on the left
            Text("Pickr")
                .font(.title2)
                .fontWeight(.bold)
            
            Spacer()
            
            // Token amount on the right
            HStack(spacing: 6) {
                Image(systemName: "bitcoinsign.circle.fill")
                Text("\(tokenStore.tokens)")
                    .font(.headline)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
        }
        .padding(.horizontal)
        .padding(.top, 8)
    }
}

#Preview {
    TopBar()
        .environmentObject(TokenStore())
}

