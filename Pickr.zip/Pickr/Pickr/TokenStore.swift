import SwiftUI

// Shared token store (global app balance + bets)
class TokenStore: ObservableObject {
    @Published var tokens: Int = 1000  // starting token amount
    
    // All placed parlays
    @Published var myTakes: [ParlayBet] = []
}

// Status of a bet (we can extend later)
enum BetStatus: String, CaseIterable, Identifiable {
    case pending
    case won
    case lost
    
    var id: String { rawValue }
}

// Bet selection used for parlays
struct BetSelection: Identifiable, Hashable {
    let id = UUID()
    let pickId: UUID          // which HotPick this belongs to
    let description: String   // e.g. "Lakers +4.5" or "Over 214.5"
    let odds: Double          // decimal odds like 1.85
}

// A full parlay bet
struct ParlayBet: Identifiable {
    let id = UUID()
    let placedAt: Date
    let legs: [BetSelection]
    let stake: Int
    let combinedOdds: Double
    let potentialReturn: Int
    var status: BetStatus = .pending
}
