import SwiftUI

struct MyTakesView: View {
    @EnvironmentObject var tokenStore: TokenStore
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TopBar()
                
                if tokenStore.myTakes.isEmpty {
                    VStack(spacing: 16) {
                        Text("My Takes")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("You don't have any plays yet.\nBuild a parlay in the Sports tab to see it here.")
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                        
                        Spacer()
                    }
                    .padding()
                } else {
                    List {
                        Section(header: Text("Your Parlays")) {
                            ForEach(tokenStore.myTakes) { bet in
                                ParlayRow(bet: bet)
                            }
                        }
                    }
                }
            }
        }
    }
}

struct ParlayRow: View {
    let bet: ParlayBet
    
    private var dateFormatter: DateFormatter {
        let df = DateFormatter()
        df.dateStyle = .short
        df.timeStyle = .short
        return df
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Parlay • \(bet.legs.count) legs")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text(bet.status.rawValue.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(.thinMaterial)
                    .clipShape(Capsule())
            }
            
            Text(dateFormatter.string(from: bet.placedAt))
                .font(.caption)
                .foregroundStyle(.secondary)
            
            ForEach(bet.legs) { leg in
                Text("• \(leg.description) @ \(leg.odds, specifier: "%.2f")x")
                    .font(.caption)
            }
            
            HStack {
                VStack(alignment: .leading) {
                    Text("Stake: \(bet.stake) tokens")
                    Text("Potential: \(bet.potentialReturn) tokens")
                }
                .font(.caption)
                
                Spacer()
            }
        }
        .padding(.vertical, 6)
    }
}

#Preview {
    MyTakesView()
        .environmentObject(TokenStore())
}
