import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var tokenStore: TokenStore
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                TopBar()
                
                VStack(alignment: .leading, spacing: 16) {
                    Text("Profile")
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Username")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("pickr_user123")
                            .font(.headline)
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Tokens")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text("\(tokenStore.tokens)")
                            .font(.headline)
                    }
                    
                    Spacer()
                }
                .padding()
            }
        }
    }
}

#Preview {
    ProfileView()
        .environmentObject(TokenStore())
}

