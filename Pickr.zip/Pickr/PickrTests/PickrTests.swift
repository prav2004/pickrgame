//
//  PickrTests.swift
//  PickrTests
//
//  Created by Praveen Nanthaseelan on 2025-11-24.
//

import Testing

struct PickrTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
