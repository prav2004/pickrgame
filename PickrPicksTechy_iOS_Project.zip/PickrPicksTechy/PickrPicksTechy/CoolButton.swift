import SwiftUI

/// A custom button with a gradient background, rounded corners and subtle
/// scaling feedback when pressed.  This view is generic over its label and
/// accepts an action closure to perform when tapped.  Use `CoolButton`
/// throughout the app to create a consistent look for interactive controls.
struct CoolButton<Label: View>: View {
    let action: () -> Void
    let label: () -> Label
    @State private var isPressed: Bool = false

    var body: some View {
        Button(action: action) {
            label()
                .padding(10)
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [Color("AccentColor").opacity(0.7), Color("AccentColor")]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .clipShape(Circle())
                .shadow(color: Color.black.opacity(isPressed ? 0.1 : 0.3), radius: isPressed ? 2 : 4, x: 0, y: isPressed ? 1 : 3)
                .scaleEffect(isPressed ? 0.9 : 1.0)
                .animation(.easeInOut(duration: 0.1), value: isPressed)
        }
        .buttonStyle(PlainButtonStyle())
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in
                    if !isPressed { isPressed = true }
                }
                .onEnded { _ in
                    isPressed = false
                }
        )
    }
}

struct CoolButton_Previews: PreviewProvider {
    static var previews: some View {
        CoolButton(action: {}) {
            Image(systemName: "star.fill")
                .foregroundColor(.white)
        }
        .previewLayout(.sizeThatFits)
        .padding()
    }
}