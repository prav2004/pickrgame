import SwiftUI

/// The root view of the app showing a tab bar with different sections.  Each
/// tab wraps a `CoolWebView` which loads a page from the live Pickr site.  By
/// keeping all web content within the same domain the user remains logged in
/// across the tabs.  If the Pickr web app evolves, simply update the URLs
/// below to point at the appropriate endpoints (for example "picks.html").
struct ContentView: View {
    /// The currently selected tab.  Binding this value allows the TabView to
    /// update its selection and maintain state across view refreshes.
    @State private var selectedTab: Tab = .home

    var body: some View {
        TabView(selection: $selectedTab) {
            CoolWebView(url: URL(string: "https://pickr-d4d9b.web.app/")!)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(Tab.home)

            CoolWebView(url: URL(string: "https://pickr-d4d9b.web.app/picks.html")!)
                .tabItem {
                    Image(systemName: "list.bullet.rectangle.portrait.fill")
                    Text("Picks")
                }
                .tag(Tab.picks)

            CoolWebView(url: URL(string: "https://pickr-d4d9b.web.app/wallet.html")!)
                .tabItem {
                    Image(systemName: "wallet.pass.fill")
                    Text("Wallet")
                }
                .tag(Tab.wallet)

            CoolWebView(url: URL(string: "https://pickr-d4d9b.web.app/leaderboard.html")!)
                .tabItem {
                    Image(systemName: "star.circle.fill")
                    Text("Leaderboard")
                }
                .tag(Tab.leaderboard)

            CoolWebView(url: URL(string: "https://pickr-d4d9b.web.app/profile.html")!)
                .tabItem {
                    Image(systemName: "person.crop.circle.fill")
                    Text("Profile")
                }
                .tag(Tab.profile)
        }
        .accentColor(Color("AccentColor"))
    }
}

/// Enumeration of the available tabs.  Conforming to `Hashable` allows each
/// case to be used as a tag on the TabView.  Add new cases here if you
/// introduce additional sections to the app.
enum Tab: Hashable {
    case home, picks, wallet, leaderboard, profile
}

/// Previews for Xcode canvas.  In release builds these are ignored.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}