import SwiftUI

/// The entry point of the PickrPicksTechy application.  This SwiftUI app
/// declares a single window group that displays the main `ContentView`.
/// All of the core navigation and web content lives in `ContentView` and the
/// helper views defined elsewhere in this project.  If you wish to customise
/// high‑level app behaviour (for example to register push notifications or
/// modify environment values) you can do so here.
@main
struct PickrPicksTechyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}