import SwiftUI
import WebKit

/// A high level wrapper around `WKWebView` that adds a custom navigation bar,
/// loading progress indicator, pull‑to‑refresh behaviour and share/open actions.
/// All state is managed by an internal `WebViewModel`.  Use this view to
/// display a website inside the app while still feeling like a native
/// experience.  The `url` passed in should be a fully qualified URL.
struct CoolWebView: View {
    /// The page to load.
    let url: URL
    /// Shared model that owns the underlying `WKWebView` and exposes
    /// observable state (title, progress, loading).
    @StateObject private var model = WebViewModel()
    /// Whether to present the iOS share sheet.
    @State private var showShareSheet: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            // Top bar: title and action buttons
            HStack {
                Text(model.title ?? "Loading…")
                    .font(.headline)
                    .lineLimit(1)
                    .accessibilityLabel("Page title")
                Spacer()
                // Refresh button
                CoolButton(action: {
                    model.webView.reload()
                }) {
                    Image(systemName: "arrow.clockwise")
                        .foregroundColor(.white)
                        .imageScale(.medium)
                }
                // Share button
                CoolButton(action: {
                    if model.webView.url != nil {
                        showShareSheet = true
                    }
                }) {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundColor(.white)
                        .imageScale(.medium)
                }
                // Open in Safari
                CoolButton(action: {
                    if let currentURL = model.webView.url {
                        UIApplication.shared.open(currentURL)
                    }
                }) {
                    Image(systemName: "safari")
                        .foregroundColor(.white)
                        .imageScale(.medium)
                }
            }
            .padding(.horizontal)
            .padding(.top, 8)

            // Loading progress bar
            if model.progress < 1.0 {
                ProgressView(value: model.progress)
                    .progressViewStyle(LinearProgressViewStyle())
                    .transition(.opacity)
                    .padding(.horizontal)
            }

            // The web content view
            WebViewContainer(url: url, model: model)
                .edgesIgnoringSafeArea(.bottom)
        }
        .sheet(isPresented: $showShareSheet) {
            if let currentURL = model.webView.url {
                ActivityView(activityItems: [currentURL])
            }
        }
        .onAppear {
            // Load the initial URL only once when this view appears for the
            // first time.  Subsequent appearances will preserve the existing
            // page state thanks to the @StateObject model.
            if model.webView.url == nil {
                model.load(url: url)
            }
        }
    }
}

// MARK: - WebViewModel

/// An observable model that owns a single `WKWebView` instance and publishes
/// changes to its title, progress and loading state.  This class uses KVO to
/// observe the `estimatedProgress` property and `title` of the underlying
/// webview.  It also provides a method to load an initial URL.
final class WebViewModel: NSObject, ObservableObject, WKNavigationDelegate {
    /// The wrapped `WKWebView`.  Note that this view is not recreated on
    /// subsequent renders; instead it is retained for the lifetime of the
    /// model which allows navigation state to persist across SwiftUI updates.
    let webView: WKWebView = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())

    @Published var title: String?
    @Published var progress: Double = 0.0
    @Published var isLoading: Bool = false

    override init() {
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // Observe progress and title via KVO
        webView.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)
        webView.addObserver(self, forKeyPath: #keyPath(WKWebView.title), options: .new, context: nil)
        // Allow pull‑to‑refresh
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshTriggered(_:)), for: .valueChanged)
        webView.scrollView.refreshControl = refreshControl
    }

    deinit {
        webView.removeObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress))
        webView.removeObserver(self, forKeyPath: #keyPath(WKWebView.title))
    }

    /// Load a URL request into the web view.  This should typically only be
    /// called once when the corresponding SwiftUI view first appears.
    func load(url: URL) {
        let request = URLRequest(url: url)
        webView.load(request)
    }

    // MARK: - KVO
    override func observeValue(
        forKeyPath keyPath: String?,
        of object: Any?,
        change: [NSKeyValueChangeKey : Any]?,
        context: UnsafeMutableRawPointer?
    ) {
        guard let webView = object as? WKWebView else { return }
        if keyPath == #keyPath(WKWebView.estimatedProgress) {
            DispatchQueue.main.async {
                self.progress = webView.estimatedProgress
            }
        } else if keyPath == #keyPath(WKWebView.title) {
            DispatchQueue.main.async {
                self.title = webView.title
            }
        }
    }

    // MARK: - Refresh control
    @objc private func refreshTriggered(_ sender: UIRefreshControl) {
        webView.reload()
        // End refreshing after a short delay to ensure the reload has begun
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            sender.endRefreshing()
        }
    }

    // MARK: - WKNavigationDelegate
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        DispatchQueue.main.async {
            self.isLoading = true
        }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.async {
            self.isLoading = false
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        DispatchQueue.main.async {
            self.isLoading = false
        }
    }
}

// MARK: - WebViewContainer

/// A `UIViewRepresentable` wrapper that hosts the `WKWebView` defined in
/// `WebViewModel`.  The web view is reused across updates so long as the
/// `model` instance remains alive.  This wrapper also ensures that the
/// web view properly fits its SwiftUI parent.
struct WebViewContainer: UIViewRepresentable {
    let url: URL
    @ObservedObject var model: WebViewModel

    func makeUIView(context: Context) -> WKWebView {
        // The model owns the web view; we simply return it here.
        return model.webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        // No update logic required; the model handles loading.
    }
}

// MARK: - ActivityView

/// A helper view that wraps `UIActivityViewController` to present the system
/// share sheet.  It takes a list of `activityItems` which can include URLs,
/// strings or other shareable objects.  We ignore updates since there is no
/// dynamic state.
struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

// MARK: - Previews

struct CoolWebView_Previews: PreviewProvider {
    static var previews: some View {
        CoolWebView(url: URL(string: "https://www.example.com")!)
    }
}