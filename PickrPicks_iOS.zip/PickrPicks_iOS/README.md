# PickrPicks iOS (SwiftUI starter)

This folder is a native iOS starter shell that matches the Pickr web app layout and is ready to wire to the same Firebase project.

Important:
- iOS apps must be built on macOS with Xcode. You can create the project on a Mac and copy these Swift files in.

## What is included
- SwiftUI tab layout (Home, Leaderboard, Wallet, Tasks, Profile)
- Firebase bootstrap (safe if Firebase SDK is not added yet)
- API config placeholder

## Steps to run on iOS (macOS + Xcode)
1. Open Xcode and create a new iOS App project.
   - Product Name: PickrPicks
   - Interface: SwiftUI
   - Language: Swift
   - Minimum iOS: 16.0
   - Bundle Identifier format: com.yourname.pickrpicks
2. Copy the Swift files from `SwiftUIStarter/` into your Xcode project.
   - Replace the generated `ContentView.swift` with `RootView.swift`.
3. Add Firebase SDKs (Swift Package Manager):
   - File > Add Packages... > https://github.com/firebase/firebase-ios-sdk
   - Select the modules you need (usually `FirebaseAuth` and `FirebaseFirestore`).
4. Set up Firebase for iOS:
   - In Firebase Console, add a new iOS app in the same project as the web app.
   - Use the same bundle identifier you chose in Xcode.
   - Download `GoogleService-Info.plist` and add it to your Xcode project target.
5. Update the API base URL in `SwiftUIStarter/Services/APIConfig.swift` if your backend uses a custom API.
6. Build and run on an iPhone simulator or device.

## Notes
- The Firebase bootstrap uses `canImport` so the app can compile before you add the Firebase SDK.
- Once Firebase is added, `FirebaseApp.configure()` will initialize automatically.
- This is a UI shell. We can wire up real data after you confirm the Firebase project and API endpoints.
