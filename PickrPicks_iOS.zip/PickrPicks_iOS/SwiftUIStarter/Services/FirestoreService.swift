import Foundation
#if canImport(FirebaseFirestore)
import FirebaseFirestore
#endif

final class FirestoreService: ObservableObject {
    static let shared = FirestoreService()

    private init() {}

    // TODO: Add Firestore queries that mirror your web app collections.
    // Example: picks, users, leaderboard, tasks, wallet activity.
}
