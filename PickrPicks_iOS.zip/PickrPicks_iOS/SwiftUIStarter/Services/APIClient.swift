import Foundation

final class APIClient {
    static let shared = APIClient()

    private init() {}

    func get(path: String) async throws -> Data {
        let url = APIConfig.baseURL.appending(path: path)
        let (data, _) = try await URLSession.shared.data(from: url)
        return data
    }

    func get(path: String, authToken: String?) async throws -> Data {
        let url = APIConfig.baseURL.appending(path: path)
        var request = URLRequest(url: url)
        if let authToken, !authToken.isEmpty {
            request.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization")
        }
        let (data, _) = try await URLSession.shared.data(for: request)
        return data
    }
}
