import Foundation
import SwiftUI
#if canImport(FirebaseAuth)
import FirebaseAuth
#endif

final class AuthService: ObservableObject {
    @Published var isSignedIn = false
    @Published var userEmail: String? = nil
    @Published var errorMessage: String? = nil
    @Published var showSignIn = false

    init() {
        refreshState()
    }

    func refreshState() {
        #if canImport(FirebaseAuth)
        let user = Auth.auth().currentUser
        isSignedIn = user != nil
        userEmail = user?.email
        #else
        isSignedIn = false
        userEmail = nil
        #endif
    }

    func fetchIdToken() async -> String? {
        #if canImport(FirebaseAuth)
        guard let user = Auth.auth().currentUser else { return nil }
        return await withCheckedContinuation { continuation in
            user.getIDTokenForcingRefresh(true) { token, _ in
                continuation.resume(returning: token)
            }
        }
        #else
        return nil
        #endif
    }

    @MainActor
    func signIn(email: String, password: String) async {
        errorMessage = nil
        #if canImport(FirebaseAuth)
        do {
            let result = try await Auth.auth().signIn(withEmail: email, password: password)
            isSignedIn = result.user != nil
            userEmail = result.user.email
            showSignIn = false
        } catch {
            errorMessage = "Sign in failed. Check your email and password."
        }
        #else
        errorMessage = "FirebaseAuth not configured yet."
        #endif
    }

    func signOut() {
        #if canImport(FirebaseAuth)
        do {
            try Auth.auth().signOut()
        } catch {
            errorMessage = "Could not sign out."
        }
        #endif
        isSignedIn = false
        userEmail = nil
    }
}
