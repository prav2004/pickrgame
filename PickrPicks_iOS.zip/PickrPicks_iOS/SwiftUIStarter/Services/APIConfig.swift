import Foundation

enum APIConfig {
    // Update if your backend uses an API server or Cloud Functions endpoint.
    static let baseURL = URL(string: "https://pickr-backend-v2-972106331799.us-central1.run.app")!
}
