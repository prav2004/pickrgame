import SwiftUI

struct RootView: View {
    @StateObject private var authService = AuthService()

    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
            }
            .tabItem { Label("Picks", systemImage: "checklist") }

            NavigationStack {
                LeaderboardView()
            }
            .tabItem { Label("Leaderboard", systemImage: "list.number") }

            NavigationStack {
                WalletView()
            }
            .tabItem { Label("Wallet", systemImage: "creditcard") }

            NavigationStack {
                TasksView()
            }
            .tabItem { Label("Tasks", systemImage: "flag.checkered") }

            NavigationStack {
                ProfileView()
            }
            .tabItem { Label("Profile", systemImage: "person.crop.circle") }
        }
        .tint(AppTheme.accent)
        .environmentObject(authService)
        .sheet(isPresented: $authService.showSignIn) {
            SignInView()
                .environmentObject(authService)
        }
        .overlay(alignment: .bottom) {
            HStack(spacing: 8) {
                Circle()
                    .fill(authService.isSignedIn ? Color.green : Color.orange)
                    .frame(width: 8, height: 8)
                Text(authService.isSignedIn ? "Sync live" : "Needs login")
                    .font(.caption2)
                    .foregroundStyle(.white)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(AppTheme.card)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(AppTheme.cardBorder, lineWidth: 1))
            .shadow(color: .black.opacity(0.25), radius: 10, x: 0, y: 6)
            .padding(.bottom, 10)
        }
    }
}
