import SwiftUI

enum AppTheme {
    static let background = LinearGradient(
        colors: [
            Color(red: 0.04, green: 0.05, blue: 0.08),
            Color(red: 0.05, green: 0.06, blue: 0.12),
            Color(red: 0.07, green: 0.07, blue: 0.10)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let card = Color(red: 0.09, green: 0.10, blue: 0.16)
    static let cardBorder = Color.white.opacity(0.08)
    static let subtle = Color.white.opacity(0.6)
    static let accent = Color(red: 1.0, green: 0.49, blue: 0.15)
}

struct AvatarPreset {
    let skin: Color
    let hair: Color
    let lip: Color
    let jersey: Color
    let accent: Color
    let hairStyle: String
}

enum AvatarCatalog {
    static let presets: [String: AvatarPreset] = [
        "avatar-1": AvatarPreset(skin: Color(hex: "#f8d7c1"), hair: Color(hex: "#5a2a18"), lip: Color(hex: "#c2410c"), jersey: Color(hex: "#0ea5e9"), accent: Color(hex: "#082f49"), hairStyle: "short"),
        "avatar-2": AvatarPreset(skin: Color(hex: "#f2c8a0"), hair: Color(hex: "#1f2937"), lip: Color(hex: "#b45309"), jersey: Color(hex: "#22c55e"), accent: Color(hex: "#064e3b"), hairStyle: "fade"),
        "avatar-3": AvatarPreset(skin: Color(hex: "#f4d6b0"), hair: Color(hex: "#0f172a"), lip: Color(hex: "#c2410c"), jersey: Color(hex: "#f97316"), accent: Color(hex: "#7c2d12"), hairStyle: "spike"),
        "avatar-4": AvatarPreset(skin: Color(hex: "#efc9a2"), hair: Color(hex: "#334155"), lip: Color(hex: "#c2410c"), jersey: Color(hex: "#a855f7"), accent: Color(hex: "#4c1d95"), hairStyle: "cap"),
        "avatar-5": AvatarPreset(skin: Color(hex: "#f5d3c8"), hair: Color(hex: "#7f1d1d"), lip: Color(hex: "#be185d"), jersey: Color(hex: "#ef4444"), accent: Color(hex: "#7f1d1d"), hairStyle: "long"),
        "avatar-6": AvatarPreset(skin: Color(hex: "#f2d1b3"), hair: Color(hex: "#312e81"), lip: Color(hex: "#be185d"), jersey: Color(hex: "#facc15"), accent: Color(hex: "#713f12"), hairStyle: "bob")
    ]

    static let aliases: [String: String] = [
        "rockstar": "avatar-3",
        "rock-star": "avatar-3",
        "spike": "avatar-3"
    ]

    static func preset(for avatarId: String?) -> AvatarPreset {
        let raw = (avatarId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if let exact = presets[raw] { return exact }
        let lowered = raw.lowercased()
        if let direct = presets[lowered] { return direct }
        if let alias = aliases[lowered], let preset = presets[alias] { return preset }
        return presets["avatar-1"] ?? AvatarPreset(skin: .gray, hair: .black, lip: .red, jersey: .blue, accent: .black, hairStyle: "short")
    }
}

struct PickrAvatar: View {
    let avatarId: String?
    let size: CGFloat

    var body: some View {
        let preset = AvatarCatalog.preset(for: avatarId)
        ZStack {
            Circle()
                .fill(preset.skin)
                .overlay(Circle().stroke(Color.white.opacity(0.18), lineWidth: 1))

            hairShape(style: preset.hairStyle)
                .fill(preset.hair)
                .frame(width: size * 1.05, height: size * hairHeight(for: preset.hairStyle))
                .offset(y: size * hairOffset(for: preset.hairStyle))

            HStack(spacing: size * 0.18) {
                Circle().fill(Color(red: 0.07, green: 0.09, blue: 0.13))
                Circle().fill(Color(red: 0.07, green: 0.09, blue: 0.13))
            }
            .frame(width: size * 0.32, height: size * 0.09)
            .offset(y: size * 0.02)

            Capsule()
                .fill(preset.lip.opacity(0.85))
                .frame(width: size * 0.26, height: size * 0.05)
                .offset(y: size * 0.18)

            Rectangle()
                .fill(preset.jersey)
                .frame(width: size * 1.2, height: size * 0.38)
                .offset(y: size * 0.42)
                .overlay(
                    Capsule()
                        .fill(Color.white.opacity(0.2))
                        .frame(width: size * 0.34, height: size * 0.12)
                        .offset(y: size * 0.36)
                )
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .shadow(color: .black.opacity(0.25), radius: 10, x: 0, y: 6)
    }

    private func hairHeight(for style: String) -> CGFloat {
        switch style {
        case "long": return 0.62
        case "bob": return 0.58
        case "cap": return 0.44
        case "fade": return 0.42
        case "spike": return 0.46
        default: return 0.48
        }
    }

    private func hairOffset(for style: String) -> CGFloat {
        switch style {
        case "long": return -0.26
        case "bob": return -0.24
        case "cap": return -0.28
        case "fade": return -0.30
        case "spike": return -0.27
        default: return -0.26
        }
    }

    @ViewBuilder
    private func hairShape(style: String) -> some Shape {
        if style == "spike" {
            SpikeHairShape()
        } else {
            RoundedRectangle(cornerRadius: size * 0.22)
        }
    }
}

struct SpikeHairShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let h = rect.height
        let w = rect.width
        path.move(to: CGPoint(x: 0, y: h))
        path.addLine(to: CGPoint(x: w * 0.12, y: h * 0.28))
        path.addLine(to: CGPoint(x: w * 0.24, y: h))
        path.addLine(to: CGPoint(x: w * 0.38, y: h * 0.24))
        path.addLine(to: CGPoint(x: w * 0.50, y: h))
        path.addLine(to: CGPoint(x: w * 0.62, y: h * 0.28))
        path.addLine(to: CGPoint(x: w * 0.76, y: h))
        path.addLine(to: CGPoint(x: w * 0.90, y: h * 0.26))
        path.addLine(to: CGPoint(x: w, y: h))
        path.addLine(to: CGPoint(x: w, y: 0))
        path.addLine(to: CGPoint(x: 0, y: 0))
        path.closeSubpath()
        return path
    }
}

extension Color {
    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var value: UInt64 = 0
        Scanner(string: cleaned).scanHexInt64(&value)
        let r, g, b: Double
        if cleaned.count == 6 {
            r = Double((value & 0xFF0000) >> 16) / 255.0
            g = Double((value & 0x00FF00) >> 8) / 255.0
            b = Double(value & 0x0000FF) / 255.0
        } else {
            r = 0.6
            g = 0.6
            b = 0.6
        }
        self.init(red: r, green: g, blue: b)
    }
}

struct AppScreen<Content: View>: View {
    let title: String
    let subtitle: String?
    let content: Content

    init(title: String, subtitle: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.content = content()
    }

    var body: some View {
        ZStack {
            AppTheme.background
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(title)
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundStyle(.white)
                        if let subtitle {
                            Text(subtitle)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                    .padding(.top, 6)

                    content
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 28)
            }
        }
    }
}

struct SectionTitle: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(AppTheme.subtle)
            .textCase(.uppercase)
            .tracking(1.2)
    }
}

struct InfoChip: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.caption2)
            .fontWeight(.semibold)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(AppTheme.card.opacity(0.9))
            .foregroundStyle(.white)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(AppTheme.cardBorder, lineWidth: 1))
    }
}

struct AccentChip: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.caption2)
            .fontWeight(.semibold)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .foregroundStyle(AppTheme.accent)
            .background(AppTheme.card)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(AppTheme.accent.opacity(0.6), lineWidth: 1))
    }
}

struct Card: View {
    let content: AnyView

    init(@ViewBuilder content: () -> some View) {
        self.content = AnyView(content())
    }

    var body: some View {
        content
            .padding(16)
            .background(AppTheme.card)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(AppTheme.cardBorder, lineWidth: 1))
            .shadow(color: .black.opacity(0.25), radius: 12, x: 0, y: 6)
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let subtitle: String?

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(AppTheme.subtle)
                Text(value)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundStyle(.white)
                if let subtitle {
                    Text(subtitle)
                        .font(.caption2)
                        .foregroundStyle(AppTheme.subtle)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

struct SyncBanner: View {
    let title: String
    let detail: String
    let statusText: String

    var body: some View {
        Card {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "bolt.horizontal.circle.fill")
                    .foregroundStyle(AppTheme.accent)
                VStack(alignment: .leading, spacing: 6) {
                    Text(title)
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text(detail)
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                    AccentChip(text: statusText)
                }
                Spacer()
            }
        }
    }
}

struct SyncRow: View {
    let label: String
    let onTap: () -> Void

    var body: some View {
        HStack {
            Text(label)
                .font(.caption2)
                .foregroundStyle(AppTheme.subtle)
            Spacer()
            Button("Sync now") {
                onTap()
            }
            .font(.caption)
            .foregroundStyle(AppTheme.accent)
        }
    }
}

struct SignInCallout: View {
    let message: String
    let onTap: () -> Void

    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Text("Sign in required")
                    .font(.headline)
                    .foregroundStyle(.white)
                Text(message)
                    .font(.caption)
                    .foregroundStyle(AppTheme.subtle)
                Button("Sign in") {
                    onTap()
                }
                .buttonStyle(.borderedProminent)
                .tint(AppTheme.accent)
            }
        }
    }
}
