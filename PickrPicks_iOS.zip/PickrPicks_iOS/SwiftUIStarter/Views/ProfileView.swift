import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var authService: AuthService

    struct ProfileResponse: Decodable {
        let screenName: String?
        let email: String?
        let avatarId: String?
        let streakWins: Double?
        let bestStreak: Double?
        let level: String?
        let xp: Double?
        let points: Double?
    }

    @State private var profile: ProfileResponse? = nil
    @State private var isLoading = false
    @State private var errorText: String? = nil
    @State private var lastUpdated: Date? = nil

    var body: some View {
        AppScreen(title: "Profile", subtitle: "Account and support") {
            SyncBanner(
                title: "Web sync",
                detail: "Sign in to sync your profile, streaks, and avatar.",
                statusText: authService.isSignedIn ? "Live" : "Needs login"
            )

            if !authService.isSignedIn {
                SignInCallout(message: "Sign in to sync your profile and avatar.") {
                    authService.showSignIn = true
                }
            }

            if authService.isSignedIn {
                SyncRow(label: lastUpdatedText) {
                    Task { await loadProfile() }
                }

                if isLoading {
                    Card {
                        HStack {
                            ProgressView()
                                .tint(AppTheme.accent)
                            Text("Loading profile…")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Spacer()
                        }
                    }
                }

                if let errorText {
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Could not load profile")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(errorText)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Account")
                        .font(.headline)
                        .foregroundStyle(.white)
                    HStack(spacing: 12) {
                        PickrAvatar(avatarId: profile?.avatarId, size: 56)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(profile?.screenName ?? "PickrFan")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(profile?.email ?? authService.userEmail ?? "you@email.com")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                        Spacer()
                    }
                    HStack {
                        Text("Status")
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        AccentChip(text: authService.isSignedIn ? "Signed in" : "Signed out")
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Stats")
                        .font(.headline)
                        .foregroundStyle(.white)
                    HStack {
                        Text("Level")
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        Text(profile?.level ?? "Bronze")
                            .foregroundStyle(.white)
                    }
                    HStack {
                        Text("XP")
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        Text(formatNumber(profile?.xp) ?? "0")
                            .foregroundStyle(.white)
                    }
                    HStack {
                        Text("Streak")
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        Text("\(formatNumber(profile?.streakWins) ?? "0") wins")
                            .foregroundStyle(.white)
                    }
                    HStack {
                        Text("Best streak")
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        Text("\(formatNumber(profile?.bestStreak) ?? "0") wins")
                            .foregroundStyle(.white)
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Social")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Link("Instagram", destination: URL(string: "https://www.instagram.com/pickrpicks/")!)
                        .foregroundStyle(.white)
                    Link("TikTok", destination: URL(string: "https://www.tiktok.com/@pickrpicks_?is_from_webapp=1&sender_device=pc")!)
                        .foregroundStyle(.white)
                    Link("LinkedIn", destination: URL(string: "https://www.linkedin.com/in/pickr-picks-a654423b2/")!)
                        .foregroundStyle(.white)
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Support")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Link("FAQ", destination: URL(string: "https://pickr-d4d9b.web.app/faq.html")!)
                        .foregroundStyle(.white)
                    Link("Terms of Service", destination: URL(string: "https://pickr-d4d9b.web.app/terms.html")!)
                        .foregroundStyle(.white)
                    Link("Contact", destination: URL(string: "https://pickr-d4d9b.web.app/contact.html")!)
                        .foregroundStyle(.white)
                }
            }

            Card {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Profile on web")
                            .font(.headline)
                            .foregroundStyle(.white)
                        Text("Open your full profile on the web app.")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                    }
                    Spacer()
                    Link("Open", destination: URL(string: "https://pickr-d4d9b.web.app/profile.html")!)
                        .font(.caption)
                        .foregroundStyle(AppTheme.accent)
                }
            }

            if authService.isSignedIn {
                Button(action: { authService.signOut() }) {
                    Text("Sign out")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .foregroundStyle(.white)
                        .background(Color.red.opacity(0.75))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task { await loadProfile() }
        .onChange(of: authService.isSignedIn) { _ in
            Task { await loadProfile() }
        }
    }

    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private var lastUpdatedText: String {
        if let lastUpdated {
            return "Updated \(formattedTime(lastUpdated))"
        }
        return "Profile sync"
    }

    private func formatNumber(_ value: Double?) -> String? {
        guard let value else { return nil }
        return NumberFormatter.localizedString(from: NSNumber(value: value), number: .decimal)
    }

    private func loadProfile() async {
        guard authService.isSignedIn else {
            profile = nil
            return
        }
        guard !isLoading else { return }
        isLoading = true
        errorText = nil
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/me", authToken: token)
            profile = try JSONDecoder().decode(ProfileResponse.self, from: data)
            lastUpdated = Date()
        } catch {
            errorText = "Please try again in a moment."
        }
        isLoading = false
    }
}
