import SwiftUI

struct HomeView: View {
    @EnvironmentObject var authService: AuthService

    struct PickItem: Identifiable {
        let id = UUID()
        let league: String
        let matchup: String
        let startTime: String
        let odds: String?
    }

    struct DailyPick: Identifiable, Decodable {
        let id: String
        let commence_time: String
        let home_team: String
        let away_team: String
        let sport_key: String
        let pickTeam: String
        let pickTeamValue: Double
        let valueScore: Double
    }

    struct GameListResponse: Decodable {
        let count: Int
        let games: [Game]
    }

    struct Game: Decodable {
        let gameId: Int?
        let startTime: String?
        let homeTeam: String?
        let awayTeam: String?
    }

    struct ProfileSnapshot: Decodable {
        let tokens: Double?
        let cash: Double?
        let cashBalance: Double?
        let streakWins: Double?
        let bestStreak: Double?
        let level: String?
        let points: Double?
    }

    @State private var remotePicks: [PickItem] = []
    @State private var isLoading = false
    @State private var errorText: String? = nil
    @State private var lastUpdated: Date? = nil

    @State private var dailyPicks: [DailyPick] = []
    @State private var dailyPicksLoading = false
    @State private var dailyPicksError: String? = nil
    @State private var dailyPicksUpdated: Date? = nil

    @State private var profileSnapshot: ProfileSnapshot? = nil
    @State private var snapshotLoading = false
    @State private var snapshotError: String? = nil
    @State private var snapshotUpdated: Date? = nil

    private let samplePicks: [PickItem] = [
        PickItem(league: "NBA", matchup: "Lakers vs Warriors", startTime: "Tonight • 7:30 PM", odds: "+115"),
        PickItem(league: "NBA", matchup: "Celtics vs Knicks", startTime: "Tonight • 8:00 PM", odds: "-110"),
        PickItem(league: "NHL", matchup: "Leafs vs Canadiens", startTime: "Tomorrow • 6:30 PM", odds: "+125")
    ]

    private let chips = ["Today", "Tomorrow", "Live", "NBA", "NHL"]

    var body: some View {
        AppScreen(title: "Picks", subtitle: "Today and next-day matchups") {
            SyncBanner(
                title: "Web sync",
                detail: "Live NBA games are pulled from pickr-backend-v2.",
                statusText: "Live"
            )

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Snapshot")
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    StatCard(title: "Tokens", value: snapshotTokensText, subtitle: snapshotTokensSubtitle)
                    StatCard(title: "Cash", value: snapshotCashText, subtitle: "Available")
                    StatCard(title: "Streak", value: snapshotStreakText, subtitle: snapshotStreakSubtitle)
                    StatCard(title: "Level", value: snapshotLevelText, subtitle: snapshotLevelSubtitle)
                }
                if authService.isSignedIn {
                    SyncRow(label: snapshotUpdatedText) {
                        Task { await loadSnapshot() }
                    }
                } else {
                    Text("Sign in to sync balances and streaks.")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(text: "Quick filters")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(chips, id: \.self) { chip in
                            InfoChip(text: chip)
                        }
                    }
                }
                HStack {
                    if let lastUpdated {
                        Text("Updated \(formattedTime(lastUpdated))")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                    } else {
                        Text("Not synced yet")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                    }
                    Spacer()
                    Button("Refresh") {
                        Task { await loadGames() }
                    }
                    .font(.caption)
                    .foregroundStyle(AppTheme.accent)
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Today")
                if isLoading {
                    Card {
                        HStack {
                            ProgressView()
                                .tint(AppTheme.accent)
                            Text("Loading games…")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Spacer()
                        }
                    }
                }
                if let errorText {
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Could not load games")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(errorText)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
                ForEach(displayedPicks) { pick in
                    Card {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text(pick.league)
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundStyle(AppTheme.accent)
                                Spacer()
                                Text(pick.startTime)
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.subtle)
                            }
                            Text(pick.matchup)
                                .font(.headline)
                                .foregroundStyle(.white)
                            if let odds = pick.odds {
                                HStack {
                                    Text("Odds")
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.subtle)
                                    Text(odds)
                                        .font(.headline)
                                        .foregroundStyle(.white)
                                    Spacer()
                                    AccentChip(text: "Make pick")
                                }
                            } else {
                                HStack {
                                    Text("Tap for details")
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.subtle)
                                    Spacer()
                                    AccentChip(text: "Open")
                                }
                            }
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Pickr Picks")
                if !authService.isSignedIn {
                    SignInCallout(message: "Sign in to see your daily Pickr Picks and sync from the web.") {
                        authService.showSignIn = true
                    }
                } else {
                    SyncRow(label: dailyPicksUpdatedText) {
                        Task { await loadDailyPicks() }
                    }
                    if dailyPicksLoading {
                        Card {
                            HStack {
                                ProgressView()
                                    .tint(AppTheme.accent)
                                Text("Loading Pickr Picks…")
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.subtle)
                                Spacer()
                            }
                        }
                    }
                    if let dailyPicksError {
                        Card {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Could not load Pickr Picks")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text(dailyPicksError)
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.subtle)
                            }
                        }
                    }
                    if dailyPicks.isEmpty && !dailyPicksLoading && dailyPicksError == nil {
                        Card {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("No picks available yet")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text("Check back after the next sync window.")
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.subtle)
                            }
                        }
                    }
                    ForEach(dailyPicks.prefix(3)) { pick in
                        Card {
                            VStack(alignment: .leading, spacing: 8) {
                                Text("\(pick.away_team) vs \(pick.home_team)")
                                    .foregroundStyle(.white)
                                Text(pick.pickTeam)
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.accent)
                                HStack {
                                    Text(formatStartTime(pick.commence_time))
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.subtle)
                                    Spacer()
                                    AccentChip(text: "\(pick.pickTeamValue)x")
                                }
                            }
                        }
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Upcoming")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("More matchups unlock after 7:00 AM local time.")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                }
            }

            Card {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Daily Spin")
                            .font(.headline)
                            .foregroundStyle(.white)
                        Text("Come back tomorrow for new rewards")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                    }
                    Spacer()
                    Image(systemName: "clock")
                        .foregroundStyle(AppTheme.subtle)
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task {
            await loadGames()
            await loadDailyPicks()
            await loadSnapshot()
        }
        .onChange(of: authService.isSignedIn) { _ in
            Task {
                await loadDailyPicks()
                await loadSnapshot()
            }
        }
    }

    private var displayedPicks: [PickItem] {
        if !remotePicks.isEmpty { return remotePicks }
        return samplePicks
    }

    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func formatNumber(_ value: Double?) -> String? {
        guard let value else { return nil }
        return NumberFormatter.localizedString(from: NSNumber(value: value), number: .decimal)
    }

    private func formatMoney(_ value: Double?) -> String? {
        guard let value else { return nil }
        return String(format: "$%.2f", value)
    }

    private var snapshotUpdatedText: String {
        if let snapshotUpdated {
            return "Updated \(formattedTime(snapshotUpdated))"
        }
        return "Snapshot sync"
    }

    private var snapshotTokensText: String {
        if let tokens = formatNumber(profileSnapshot?.tokens) { return tokens }
        return "1,240"
    }

    private var snapshotTokensSubtitle: String? {
        if let cash = formatMoney(profileSnapshot?.cash ?? profileSnapshot?.cashBalance) {
            return "\(cash) CAD"
        }
        return "$12.40 CAD"
    }

    private var snapshotCashText: String {
        if let cash = formatMoney(profileSnapshot?.cash ?? profileSnapshot?.cashBalance) { return cash }
        return "$12.40"
    }

    private var snapshotStreakText: String {
        if let streak = formatNumber(profileSnapshot?.streakWins) {
            return "\(streak) wins"
        }
        return "4 wins"
    }

    private var snapshotStreakSubtitle: String? {
        if let best = formatNumber(profileSnapshot?.bestStreak) {
            return "Best \(best)"
        }
        return "This week"
    }

    private var snapshotLevelText: String {
        profileSnapshot?.level ?? "Bronze"
    }

    private var snapshotLevelSubtitle: String? {
        if let points = formatNumber(profileSnapshot?.points) {
            return "\(points) points"
        }
        return "Weekly"
    }

    private var dailyPicksUpdatedText: String {
        if let dailyPicksUpdated {
            return "Updated \(formattedTime(dailyPicksUpdated))"
        }
        return "Daily picks sync"
    }

    private func parseStartTime(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "TBD" }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: raw) {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
        return raw
    }

    private func formatStartTime(_ raw: String) -> String {
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: raw) {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
        return raw
    }

    private func loadGames() async {
        guard !isLoading else { return }
        isLoading = true
        errorText = nil
        do {
            let data = try await APIClient.shared.get(path: "/api/games/nba/list-public")
            let decoded = try JSONDecoder().decode(GameListResponse.self, from: data)
            let mapped = decoded.games.map { game in
                let home = game.homeTeam ?? "Home"
                let away = game.awayTeam ?? "Away"
                return PickItem(
                    league: "NBA",
                    matchup: "\(away) vs \(home)",
                    startTime: parseStartTime(game.startTime),
                    odds: nil
                )
            }
            remotePicks = mapped
            lastUpdated = Date()
        } catch {
            errorText = "Please try again in a moment."
        }
        isLoading = false
    }

    private func loadDailyPicks() async {
        guard authService.isSignedIn else {
            dailyPicks = []
            dailyPicksError = nil
            return
        }
        guard !dailyPicksLoading else { return }
        dailyPicksLoading = true
        dailyPicksError = nil
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/dailyPicks", authToken: token)
            dailyPicks = try JSONDecoder().decode([DailyPick].self, from: data)
            dailyPicksUpdated = Date()
        } catch {
            dailyPicksError = "Please try again in a moment."
        }
        dailyPicksLoading = false
    }

    private func loadSnapshot() async {
        guard authService.isSignedIn else {
            profileSnapshot = nil
            snapshotError = nil
            return
        }
        guard !snapshotLoading else { return }
        snapshotLoading = true
        snapshotError = nil
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/me", authToken: token)
            profileSnapshot = try JSONDecoder().decode(ProfileSnapshot.self, from: data)
            snapshotUpdated = Date()
        } catch {
            snapshotError = "Please try again in a moment."
        }
        snapshotLoading = false
    }
}
