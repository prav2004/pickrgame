import SwiftUI

struct WalletView: View {
    @EnvironmentObject var authService: AuthService
    struct Activity: Identifiable {
        let id = UUID()
        let title: String
        let detail: String
    }

    private let activities = [
        Activity(title: "Win vs Warriors", detail: "+120 Tokens"),
        Activity(title: "Daily Task Bonus", detail: "+25 Tokens"),
        Activity(title: "Loss vs Knicks", detail: "-40 Tokens")
    ]

    struct ProfileResponse: Decodable {
        let tokens: Double
        let cash: Double
        let cashBalance: Double?
        let streakWins: Double?
        let bestStreak: Double?
        let level: String?
        let xp: Double?
        let screenName: String?
        let email: String?
        let avatarId: String?
    }

    @State private var profile: ProfileResponse? = nil
    @State private var isLoading = false
    @State private var errorText: String? = nil
    @State private var lastUpdated: Date? = nil

    var body: some View {
        AppScreen(title: "Wallet", subtitle: "Balances and recent activity") {
            SyncBanner(
                title: "Web sync",
                detail: "Sign in on iOS to pull your real token and cash balances.",
                statusText: authService.isSignedIn ? "Live" : "Needs login"
            )

            if !authService.isSignedIn {
                SignInCallout(message: "Sign in to see your real wallet balances and activity.") {
                    authService.showSignIn = true
                }
            }

            if authService.isSignedIn {
                SyncRow(label: lastUpdatedText) {
                    Task { await loadProfileIfNeeded() }
                }

                if isLoading {
                    Card {
                        HStack {
                            ProgressView()
                                .tint(AppTheme.accent)
                            Text("Loading wallet…")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Spacer()
                        }
                    }
                }
                if let errorText {
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Could not load wallet")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(errorText)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
            }

            if authService.isSignedIn {
                Card {
                    HStack(spacing: 12) {
                        PickrAvatar(avatarId: profile?.avatarId, size: 48)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(profile?.screenName ?? "PickrFan")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(profile?.email ?? authService.userEmail ?? "you@email.com")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                        Spacer()
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Balances")
                        .font(.headline)
                        .foregroundStyle(.white)
                    HStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Tokens")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Text(formattedTokens)
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                        }
                        Divider().background(AppTheme.cardBorder)
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Cash")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Text(formattedCash)
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                        }
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Withdrawals")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("Unlock cash withdrawals after completing a verified partner task.")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                    HStack {
                        Text("Status")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                        Spacer()
                        AccentChip(text: "Locked")
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Recent activity")
                ForEach(activities) { activity in
                    Card {
                        HStack {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(activity.title)
                                    .foregroundStyle(.white)
                                Text(activity.detail)
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.subtle)
                            }
                            Spacer()
                        }
                    }
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task { await loadProfileIfNeeded() }
        .onChange(of: authService.isSignedIn) { _ in
            Task { await loadProfileIfNeeded() }
        }
    }

    private var formattedTokens: String {
        let value = profile?.tokens ?? 1240
        return NumberFormatter.localizedString(from: NSNumber(value: value), number: .decimal)
    }

    private var formattedCash: String {
        let value = profile?.cash ?? 12.40
        return String(format: "$%.2f CAD", value)
    }

    private var lastUpdatedText: String {
        if let lastUpdated {
            return "Updated \(formattedTime(lastUpdated))"
        }
        return "Wallet sync"
    }

    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func loadProfileIfNeeded() async {
        guard authService.isSignedIn else {
            profile = nil
            return
        }
        guard !isLoading else { return }
        isLoading = true
        errorText = nil
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/me", authToken: token)
            profile = try JSONDecoder().decode(ProfileResponse.self, from: data)
            lastUpdated = Date()
        } catch {
            errorText = "Please try again in a moment."
        }
        isLoading = false
    }
}
