import SwiftUI

struct TasksView: View {
    @EnvironmentObject var authService: AuthService
    struct TaskItem: Identifiable {
        let id = UUID()
        let title: String
        let detail: String
    }

    struct DailyPick: Identifiable, Decodable {
        let id: String
        let commence_time: String
        let home_team: String
        let away_team: String
        let sport_key: String
        let pickTeam: String
        let pickTeamValue: Double
        let valueScore: Double
    }

    struct ProfileResponse: Decodable {
        let screenName: String?
        let email: String?
        let avatarId: String?
    }

    @State private var dailyPicks: [DailyPick] = []
    @State private var isLoading = false
    @State private var errorText: String? = nil
    @State private var lastUpdated: Date? = nil
    @State private var profile: ProfileResponse? = nil

    private let starter = [
        TaskItem(title: "Create a username", detail: "Complete your profile"),
        TaskItem(title: "Make your first pick", detail: "Earn your starter tokens")
    ]

    private let daily = [
        TaskItem(title: "Place 3 picks", detail: "+40 Tokens"),
        TaskItem(title: "Share your win", detail: "+15 Tokens")
    ]

    private let weekly = [
        TaskItem(title: "Win 5 picks", detail: "+200 Tokens"),
        TaskItem(title: "Invite a friend", detail: "+100 Tokens")
    ]

    var body: some View {
        AppScreen(title: "Tasks", subtitle: "Daily, weekly, and partner tasks") {
            SyncBanner(
                title: "Web sync",
                detail: "Connect your account to sync task progress and rewards.",
                statusText: authService.isSignedIn ? "Live" : "Needs login"
            )

            if !authService.isSignedIn {
                SignInCallout(message: "Sign in to sync task progress and rewards with the web app.") {
                    authService.showSignIn = true
                }
            }

            if authService.isSignedIn {
                Card {
                    HStack(spacing: 12) {
                        PickrAvatar(avatarId: profile?.avatarId, size: 48)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(profile?.screenName ?? "PickrFan")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(profile?.email ?? authService.userEmail ?? "you@email.com")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                        Spacer()
                    }
                }

                SyncRow(label: lastUpdatedText) {
                    Task { await loadDailyPicks() }
                }

                if isLoading {
                    Card {
                        HStack {
                            ProgressView()
                                .tint(AppTheme.accent)
                            Text("Loading daily picks…")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Spacer()
                        }
                    }
                }

                if let errorText {
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Could not load daily picks")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(errorText)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }

                if !dailyPicks.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Daily picks")
                        ForEach(dailyPicks.prefix(5)) { pick in
                            Card {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("\(pick.away_team) vs \(pick.home_team)")
                                        .foregroundStyle(.white)
                                    Text(pick.pickTeam)
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.accent)
                                    HStack {
                                        Text(formatStartTime(pick.commence_time))
                                            .font(.caption)
                                            .foregroundStyle(AppTheme.subtle)
                                        Spacer()
                                        AccentChip(text: "\(pick.pickTeamValue)x")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Starter quests")
                ForEach(starter) { task in
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(task.title)
                                .foregroundStyle(.white)
                            Text(task.detail)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Partner Task")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("Complete an approved partner task to unlock cash withdrawals.")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                    HStack {
                        Text("OLG PROLINE")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundStyle(AppTheme.accent)
                        Spacer()
                        InfoChip(text: "Not started")
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Daily tasks")
                ForEach(daily) { task in
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(task.title)
                                .foregroundStyle(.white)
                            Text(task.detail)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Weekly quests")
                ForEach(weekly) { task in
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(task.title)
                                .foregroundStyle(.white)
                            Text(task.detail)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task {
            await loadDailyPicks()
            await loadProfileIfNeeded()
        }
        .onChange(of: authService.isSignedIn) { _ in
            Task {
                await loadDailyPicks()
                await loadProfileIfNeeded()
            }
        }
    }

    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private var lastUpdatedText: String {
        if let lastUpdated {
            return "Updated \(formattedTime(lastUpdated))"
        }
        return "Daily picks sync"
    }

    private func formatStartTime(_ raw: String) -> String {
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: raw) {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
        return raw
    }

    private func loadDailyPicks() async {
        guard authService.isSignedIn else {
            dailyPicks = []
            return
        }
        guard !isLoading else { return }
        isLoading = true
        errorText = nil
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/dailyPicks", authToken: token)
            dailyPicks = try JSONDecoder().decode([DailyPick].self, from: data)
            lastUpdated = Date()
        } catch {
            errorText = "Please try again in a moment."
        }
        isLoading = false
    }

    private func loadProfileIfNeeded() async {
        guard authService.isSignedIn else {
            profile = nil
            return
        }
        do {
            let token = await authService.fetchIdToken()
            let data = try await APIClient.shared.get(path: "/api/me", authToken: token)
            profile = try JSONDecoder().decode(ProfileResponse.self, from: data)
        } catch {
            profile = nil
        }
    }
}
