import SwiftUI

struct LeaderboardView: View {
    struct LeaderRow: Identifiable {
        let id = UUID()
        let name: String
        let points: Int
        let level: String
        let avatarId: String?
    }

    struct LeaderboardResponse: Decodable {
        let players: [Player]
    }

    struct Player: Decodable {
        let name: String
        let points: Int
        let level: String?
        let avatarId: String?
    }

    @State private var remoteLeaders: [LeaderRow] = []
    @State private var isLoading = false
    @State private var errorText: String? = nil
    @State private var lastUpdated: Date? = nil

    private let sampleLeaders: [LeaderRow] = [
        LeaderRow(name: "Tony", points: 1200, level: "Gold", avatarId: "avatar-3"),
        LeaderRow(name: "Riya", points: 980, level: "Silver", avatarId: "avatar-2"),
        LeaderRow(name: "Marcus", points: 910, level: "Silver", avatarId: "avatar-4"),
        LeaderRow(name: "Hana", points: 860, level: "Bronze", avatarId: "avatar-5"),
        LeaderRow(name: "Devin", points: 840, level: "Bronze", avatarId: "avatar-1")
    ]

    var body: some View {
        AppScreen(title: "Leaderboard", subtitle: "Weekly top performers") {
            SyncBanner(
                title: "Web sync",
                detail: "Leaderboard pulls live points from your web backend.",
                statusText: "Live"
            )

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Top 3")
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(displayedLeaders.prefix(3)) { leader in
                            Card {
                                VStack(alignment: .leading, spacing: 10) {
                                    PickrAvatar(avatarId: leader.avatarId, size: 44)
                                    Text(leader.name)
                                        .font(.headline)
                                        .foregroundStyle(.white)
                                    Text("\(leader.points) pts • \(leader.level)")
                                        .font(.caption)
                                        .foregroundStyle(AppTheme.subtle)
                                }
                                .frame(width: 160, alignment: .leading)
                            }
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 12) {
                SectionTitle(text: "Rankings")
                HStack {
                    if let lastUpdated {
                        Text("Updated \(formattedTime(lastUpdated))")
                            .font(.caption2)
                            .foregroundStyle(AppTheme.subtle)
                    } else {
                        Text("Updated hourly")
                            .font(.caption2)
                            .foregroundStyle(AppTheme.subtle)
                    }
                    Spacer()
                    Button("Refresh") {
                        Task { await loadLeaders() }
                    }
                    .font(.caption)
                    .foregroundStyle(AppTheme.accent)
                }
                if isLoading {
                    Card {
                        HStack {
                            ProgressView()
                                .tint(AppTheme.accent)
                            Text("Loading leaderboard…")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                            Spacer()
                        }
                    }
                }
                if let errorText {
                    Card {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Could not load leaderboard")
                                .font(.headline)
                                .foregroundStyle(.white)
                            Text(errorText)
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                        }
                    }
                }
                ForEach(Array(displayedLeaders.enumerated()), id: \.offset) { index, leader in
                    Card {
                        HStack {
                            Text("#\(index + 1)")
                                .font(.caption)
                                .foregroundStyle(AppTheme.subtle)
                                .frame(width: 34, alignment: .leading)
                            PickrAvatar(avatarId: leader.avatarId, size: 28)
                            Text(leader.name)
                                .foregroundStyle(.white)
                            Spacer()
                            VStack(alignment: .trailing, spacing: 4) {
                                Text("\(leader.points)")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text(leader.level)
                                    .font(.caption2)
                                    .foregroundStyle(AppTheme.subtle)
                            }
                        }
                    }
                }
            }

            Card {
                HStack {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Full leaderboard")
                            .font(.headline)
                            .foregroundStyle(.white)
                        Text("Open the web leaderboard for full rankings.")
                            .font(.caption)
                            .foregroundStyle(AppTheme.subtle)
                    }
                    Spacer()
                    Link("Open", destination: URL(string: "https://pickr-d4d9b.web.app/leaderboard-full.html")!)
                        .font(.caption)
                        .foregroundStyle(AppTheme.accent)
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task { await loadLeaders() }
    }

    private var displayedLeaders: [LeaderRow] {
        if !remoteLeaders.isEmpty { return remoteLeaders }
        return sampleLeaders
    }

    private func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func loadLeaders() async {
        guard !isLoading else { return }
        isLoading = true
        errorText = nil
        do {
            let data = try await APIClient.shared.get(path: "/api/leaderboard/players?limit=50")
            let decoded = try JSONDecoder().decode(LeaderboardResponse.self, from: data)
            remoteLeaders = decoded.players.map {
                LeaderRow(name: $0.name, points: $0.points, level: $0.level ?? "Bronze", avatarId: $0.avatarId)
            }
            lastUpdated = Date()
        } catch {
            errorText = "Please try again in a moment."
        }
        isLoading = false
    }
}
