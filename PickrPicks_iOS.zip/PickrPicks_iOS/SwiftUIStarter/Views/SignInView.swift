import SwiftUI

struct SignInView: View {
    @EnvironmentObject var authService: AuthService
    @State private var email = ""
    @State private var password = ""

    var body: some View {
        AppScreen(title: "Sign in", subtitle: "Sync your account with the web app") {
            Card {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Email")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                    TextField("you@email.com", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .textFieldStyle(.roundedBorder)

                    Text("Password")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                    SecureField("Your password", text: $password)
                        .textFieldStyle(.roundedBorder)

                    if let error = authService.errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }

                    Button("Sign in") {
                        Task { await authService.signIn(email: email, password: password) }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.accent)
                }
            }

            Card {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Need Firebase setup")
                        .font(.headline)
                        .foregroundStyle(.white)
                    Text("Add FirebaseAuth via Swift Package Manager on your iMac, then this screen will authenticate with the same Firebase project as the web app.")
                        .font(.caption)
                        .foregroundStyle(AppTheme.subtle)
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }
}
